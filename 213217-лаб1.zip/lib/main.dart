import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final List<Map<String, String>> products = [
    {
      "name": "Маица",
      "image": "assets/maica.jpg",
      "description": "Памучна маица, совршена за секојдневие.",
      "price": "500 ден."
    },
    {
      "name": "Панталони",
      "image": "assets/pants.jpg",
      "description": "Удобни панталони, идеални за формални прилики.",
      "price": "1200 ден."
    },
    {
      "name": "Јакна",
      "image": "assets/jakna.jpg",
      "description": "Топла јакна, идеална за зима.",
      "price": "2500 ден."
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('213217'), // Ставете го вашиот индекс тука.
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Card(
            child: ListTile(
              leading: Image.asset(product["image"]!),
              title: Text(product["name"]!),
              subtitle: Text(product["price"]!),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProductDetailScreen(product: product),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class ProductDetailScreen extends StatelessWidget {
  final Map<String, String> product;

  ProductDetailScreen({required this.product});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(product["name"]!),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(product["image"]!),
            SizedBox(height: 16),
            Text(
              product["name"]!,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(product["description"]!),
            SizedBox(height: 16),
            Text(
              'Цена: ${product["price"]!}',
              style: TextStyle(fontSize: 18, color: Colors.green),
            ),
          ],
        ),
      ),
    );
  }
}
